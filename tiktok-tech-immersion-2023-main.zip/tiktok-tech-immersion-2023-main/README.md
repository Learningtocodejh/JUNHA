# assignment_demo_2023

![Tests](https://github.com/weixingp/tiktok-tech-immersion-2023/actions/workflows/test.yml/badge.svg)

This is a completed project for backend assignment of 2023 TikTok Tech Immersion.
